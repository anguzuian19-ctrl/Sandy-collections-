# Sandy Collections

Full system: customer storefront + manager admin dashboard, one Node.js app, one database.
Express + SQLite, server-rendered — no build step, easy to run on a small VPS.

- **Storefront** (`/`) — public shop: browse, cart, checkout, mobile money payment, order tracking
- **Admin** (`/admin`) — manager tool: products, stock, discounts, sales, financial reports

Both read/write the same SQLite database, so a storefront sale shows up in admin reports
instantly — there's no syncing step.

## What's inside

**Storefront**
- Catalog with search + category filter, product pages with photo gallery
- Size/color variant picker with live stock and discount pricing
- Session-based cart (no customer account needed) and guest checkout
- Mobile money payment: pay-to-number instructions + reference submission (see Payments below)
- Order status page (bookmarkable link, no login) that updates once you confirm payment

**Admin**
- **Products** — name, description, category, photos, per size/color variants
- **Stock** — per-variant quantity, low-stock threshold, restock/adjustment log, auto-decrements on sale
- **Discounts** — percent or fixed, scoped to all products / a category / one product, optional date window
- **Sales** — in-person sales entered manually; online orders appear automatically as "pending" until you confirm payment
- **Reports** — revenue trend, profit & margin, top sellers, discount impact, low stock, stock value

Currency is displayed as UGX. To change it, search for `UGX` across `views/**/*.ejs` and replace.

## Payments — how checkout actually works right now

There's no payment aggregator wired in yet. Checkout uses a **direct mobile money flow**:

1. Customer checks out → order is created as `pending`, stock is reserved immediately
2. They're shown your MTN MoMo / Airtel Money number and the exact USSD steps to pay you directly
3. They type in the transaction ID from their confirmation SMS
4. You see it under **Admin → Sales → Pending** (also flagged on the Overview dashboard), check it
   against your own phone, and click **Mark as paid** or **Cancel & restock**

No fees, no integration, works from day one. This is the standard stopgap Ugandan shops use
before they have an aggregator account — it's a real, working payment flow for a client demo,
not a placeholder that silently does nothing.

**Set your numbers** in `.env`:
```
MTN_MOMO_NUMBER=07XXXXXXXX
AIRTEL_MONEY_NUMBER=07XXXXXXXX
```

### Swapping in Xyle later

The whole flow talks to a single interface in `services/payments/`, so switching providers
is a one-line config change, not a rewrite:

- `services/payments/manual.js` — what's live now (above)
- `services/payments/xyle.js` — stub with the same function shape, commented with exactly
  what to fill in once you have the API key and docs
- `services/payments/index.js` — picks the provider based on `PAYMENT_PROVIDER` in `.env`

When Xyle access comes through: implement the two functions in `xyle.js`, set
`PAYMENT_PROVIDER=xyle` in `.env`, restart. `routes/shop.js` doesn't change at all.

## 1. Local setup (test before deploying)

Requires Node.js 18+.

```bash
npm install
cp .env.example .env
# open .env and set SESSION_SECRET to a random string:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
# set MTN_MOMO_NUMBER / AIRTEL_MONEY_NUMBER to your real numbers

# create your manager login
node db/seed-admin.js <username> <password>

npm start
```

Visit `http://localhost:3000` for the shop, `http://localhost:3000/admin` to log in and manage it.

## 2. Deploying to your VPS

Same steps as local setup, run on the server, plus a process manager and a reverse proxy
so it survives reboots and gets a real domain/HTTPS.

```bash
# on the VPS
git clone <your-repo-url> sandy-collections      # or scp the folder over
cd sandy-collections
npm install --omit=dev
cp .env.example .env
nano .env        # SESSION_SECRET, MTN/Airtel numbers, NODE_ENV=production
node db/seed-admin.js <username> <password>
```

**Run it with PM2** so it restarts on crash/reboot:

```bash
npm install -g pm2
pm2 start server.js --name sandy-collections
pm2 save
pm2 startup        # follow the printed instructions once
```

**Nginx reverse proxy** — point your domain at the app. Storefront and admin are the same
app (admin is just `/admin`), so one server block covers both:

```nginx
server {
    listen 80;
    server_name sandycollections.com www.sandycollections.com;

    client_max_body_size 25M;   # allow product photo uploads

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Then get a certificate: `sudo certbot --nginx -d sandycollections.com -d www.sandycollections.com`

If port 3000 is already used by something else on your VPS, change `PORT` in `.env` and
the `proxy_pass` line to match.

## 3. Backups

Everything that matters lives in two places — back these up regularly (a nightly cron
with `rsync` or `cp` to another disk/bucket is enough):

- `db/sandy.db` — products, stock, all sales/orders, reports data
- `uploads/` — product photos

## 4. Day-to-day notes

- **Discounts stack rule**: if more than one discount could apply to an item, the
  system uses whichever gives the bigger saving — never both at once.
- **Overselling is blocked**: both storefront checkout and admin manual sales reject
  a sale if there isn't enough stock for any line item — nothing is saved, stock is untouched.
- **Online orders reserve stock immediately** at checkout, before payment is confirmed.
  If you cancel a pending order, that stock is automatically put back.
- **Low stock threshold** is per size/color, not per product — set it when you add
  the variant, editable anytime.
- Deleting a product deletes its photos, variants, and stock history. Uncheck
  "Visible on storefront" instead if you just want to hide it without losing history.
- The admin sidebar has a **"View shop"** link to jump to the storefront; the storefront
  has no visible admin link on purpose — go to `/admin` directly.

## 5. What's next

- Swap in Xyle once you have API access (see Payments above) — no other changes needed
- Optional: email/SMS notification when an order is confirmed, instead of the customer
  having to revisit their order link
- Optional: customer accounts / order history (currently guest checkout only, tracked by link)
