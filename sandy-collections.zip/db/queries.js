const db = require('./db');
const dayjs = require('dayjs');

// ---------- Categories ----------
function listCategories() {
  return db.prepare('SELECT * FROM categories ORDER BY name').all();
}
function createCategory(name) {
  return db.prepare('INSERT OR IGNORE INTO categories (name) VALUES (?)').run(name);
}

// ---------- Products ----------
function listProducts({ search = '', categoryId = null, activeOnly = false } = {}) {
  let sql = `
    SELECT p.*, c.name AS category_name,
      (SELECT filename FROM product_images pi WHERE pi.product_id = p.id ORDER BY is_primary DESC, sort_order ASC LIMIT 1) AS cover_image,
      (SELECT COALESCE(SUM(stock_qty),0) FROM variants v WHERE v.product_id = p.id) AS total_stock,
      (SELECT MIN(price) FROM variants v WHERE v.product_id = p.id) AS min_price,
      (SELECT MAX(price) FROM variants v WHERE v.product_id = p.id) AS max_price
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    WHERE 1=1
  `;
  const params = [];
  if (search) {
    sql += ' AND p.name LIKE ?';
    params.push(`%${search}%`);
  }
  if (categoryId) {
    sql += ' AND p.category_id = ?';
    params.push(categoryId);
  }
  if (activeOnly) {
    sql += ' AND p.is_active = 1';
  }
  sql += ' ORDER BY p.created_at DESC';
  return db.prepare(sql).all(...params);
}

function getProduct(id) {
  const product = db.prepare(`
    SELECT p.*, c.name AS category_name FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    WHERE p.id = ?
  `).get(id);
  if (!product) return null;
  product.images = db.prepare('SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC').all(id);
  product.variants = db.prepare('SELECT * FROM variants WHERE product_id = ? ORDER BY size, color').all(id);
  return product;
}

function createProduct({ name, description, category_id }) {
  const info = db.prepare('INSERT INTO products (name, description, category_id) VALUES (?, ?, ?)')
    .run(name, description || null, category_id || null);
  return info.lastInsertRowid;
}

function updateProduct(id, { name, description, category_id, is_active }) {
  db.prepare(`
    UPDATE products SET name = ?, description = ?, category_id = ?, is_active = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(name, description || null, category_id || null, is_active ? 1 : 0, id);
}

function deleteProduct(id) {
  db.prepare('DELETE FROM products WHERE id = ?').run(id); // cascades images + variants
}

function addImage(product_id, filename, isPrimary = false) {
  if (isPrimary) {
    db.prepare('UPDATE product_images SET is_primary = 0 WHERE product_id = ?').run(product_id);
  }
  return db.prepare('INSERT INTO product_images (product_id, filename, is_primary) VALUES (?, ?, ?)')
    .run(product_id, filename, isPrimary ? 1 : 0).lastInsertRowid;
}

function deleteImage(id) {
  const img = db.prepare('SELECT * FROM product_images WHERE id = ?').get(id);
  db.prepare('DELETE FROM product_images WHERE id = ?').run(id);
  return img;
}

function setPrimaryImage(product_id, image_id) {
  db.prepare('UPDATE product_images SET is_primary = 0 WHERE product_id = ?').run(product_id);
  db.prepare('UPDATE product_images SET is_primary = 1 WHERE id = ? AND product_id = ?').run(image_id, product_id);
}

// ---------- Variants ----------
function addVariant(product_id, { size, color, sku, price, cost_price, stock_qty, low_stock_threshold }) {
  return db.prepare(`
    INSERT INTO variants (product_id, size, color, sku, price, cost_price, stock_qty, low_stock_threshold)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(product_id, size || null, color || null, sku || null, price, cost_price || 0, stock_qty || 0, low_stock_threshold || 3).lastInsertRowid;
}

function updateVariant(id, { size, color, sku, price, cost_price, low_stock_threshold, is_active }) {
  db.prepare(`
    UPDATE variants SET size = ?, color = ?, sku = ?, price = ?, cost_price = ?, low_stock_threshold = ?, is_active = ?
    WHERE id = ?
  `).run(size || null, color || null, sku || null, price, cost_price || 0, low_stock_threshold || 3, is_active ? 1 : 0, id);
}

function deleteVariant(id) {
  db.prepare('DELETE FROM variants WHERE id = ?').run(id);
}

function getVariant(id) {
  return db.prepare(`
    SELECT v.*, p.name AS product_name FROM variants v
    JOIN products p ON p.id = v.product_id
    WHERE v.id = ?
  `).get(id);
}

// Used by the storefront cart/checkout — variant + product name + cover photo in one row.
function getVariantWithProduct(id) {
  return db.prepare(`
    SELECT v.*, p.name AS product_name,
      (SELECT filename FROM product_images pi WHERE pi.product_id = p.id ORDER BY is_primary DESC, sort_order ASC LIMIT 1) AS cover_image
    FROM variants v
    JOIN products p ON p.id = v.product_id
    WHERE v.id = ?
  `).get(id);
}

function adjustStock(variant_id, changeQty, reason, note = null) {
  const tx = db.transaction(() => {
    db.prepare('UPDATE variants SET stock_qty = stock_qty + ? WHERE id = ?').run(changeQty, variant_id);
    db.prepare('INSERT INTO stock_movements (variant_id, change_qty, reason, note) VALUES (?, ?, ?, ?)')
      .run(variant_id, changeQty, reason, note);
  });
  tx();
}

function lowStockVariants(defaultThreshold = null) {
  return db.prepare(`
    SELECT v.*, p.name AS product_name FROM variants v
    JOIN products p ON p.id = v.product_id
    WHERE v.is_active = 1 AND v.stock_qty <= v.low_stock_threshold
    ORDER BY v.stock_qty ASC
  `).all();
}

// ---------- Discounts ----------
function listDiscounts() {
  return db.prepare(`
    SELECT d.*,
      CASE d.scope WHEN 'product' THEN (SELECT name FROM products WHERE id = d.scope_id)
                   WHEN 'category' THEN (SELECT name FROM categories WHERE id = d.scope_id)
                   ELSE 'All products' END AS scope_name
    FROM discounts d ORDER BY d.created_at DESC
  `).all();
}

function createDiscount({ name, type, value, scope, scope_id, start_date, end_date }) {
  return db.prepare(`
    INSERT INTO discounts (name, type, value, scope, scope_id, start_date, end_date)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(name, type, value, scope, scope === 'all' ? null : scope_id, start_date || null, end_date || null).lastInsertRowid;
}

function toggleDiscount(id, isActive) {
  db.prepare('UPDATE discounts SET is_active = ? WHERE id = ?').run(isActive ? 1 : 0, id);
}

function deleteDiscount(id) {
  db.prepare('DELETE FROM discounts WHERE id = ?').run(id);
}

// Returns the best applicable discount for a given variant right now, or null.
function getEffectiveDiscount(variant) {
  const today = dayjs().format('YYYY-MM-DD');
  const product = db.prepare('SELECT category_id FROM products WHERE id = ?').get(variant.product_id);
  const discounts = db.prepare(`
    SELECT * FROM discounts WHERE is_active = 1
      AND (start_date IS NULL OR start_date <= ?)
      AND (end_date IS NULL OR end_date >= ?)
      AND (
        (scope = 'all') OR
        (scope = 'product' AND scope_id = ?) OR
        (scope = 'category' AND scope_id = ?)
      )
  `).all(today, today, variant.product_id, product ? product.category_id : -1);

  if (!discounts.length) return null;

  let best = null;
  let bestAmount = -1;
  for (const d of discounts) {
    const amount = d.type === 'percent' ? variant.price * (d.value / 100) : Math.min(d.value, variant.price);
    if (amount > bestAmount) { bestAmount = amount; best = d; }
  }
  return best ? { discount: best, amount: bestAmount, finalPrice: Math.max(0, variant.price - bestAmount) } : null;
}

// ---------- Sales ----------
// Shared core: records a sale/order, decrements stock, applies the best discount per line.
// items: [{ variant_id, quantity }]
function _recordSale({ items, customer_name, customer_phone, delivery_note, channel, payment_method, status, publicToken }) {
  if (!items || !items.length) throw new Error('Sale must have at least one item');

  const tx = db.transaction(() => {
    let total = 0;
    let discountTotal = 0;
    const saleId = db.prepare(`
      INSERT INTO sales (customer_name, customer_phone, delivery_note, channel, total_amount, discount_amount, payment_method, status, public_token)
      VALUES (?, ?, ?, ?, 0, 0, ?, ?, ?)
    `).run(
      customer_name || null, customer_phone || null, delivery_note || null,
      channel || 'in_person', payment_method || null, status || 'completed', publicToken || null
    ).lastInsertRowid;

    for (const item of items) {
      const variant = db.prepare('SELECT * FROM variants WHERE id = ?').get(item.variant_id);
      if (!variant) throw new Error(`Variant ${item.variant_id} not found`);
      if (variant.stock_qty < item.quantity) {
        throw new Error(`Not enough stock for ${variant.sku || (variant.size || '') + ' ' + (variant.color || '')} (have ${variant.stock_qty}, need ${item.quantity})`);
      }
      const eff = getEffectiveDiscount(variant);
      const unitPrice = eff ? eff.finalPrice : variant.price;
      const lineDiscount = eff ? eff.amount * item.quantity : 0;

      db.prepare(`
        INSERT INTO sale_items (sale_id, variant_id, quantity, unit_price, cost_price, discount_id, discount_amount)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(saleId, item.variant_id, item.quantity, unitPrice, variant.cost_price, eff ? eff.discount.id : null, lineDiscount);

      db.prepare('UPDATE variants SET stock_qty = stock_qty - ? WHERE id = ?').run(item.quantity, item.variant_id);
      db.prepare('INSERT INTO stock_movements (variant_id, change_qty, reason, note) VALUES (?, ?, ?, ?)')
        .run(item.variant_id, -item.quantity, 'sale', `Sale #${saleId}`);

      total += unitPrice * item.quantity;
      discountTotal += lineDiscount;
    }

    db.prepare('UPDATE sales SET total_amount = ?, discount_amount = ? WHERE id = ?').run(total, discountTotal, saleId);
    return saleId;
  });

  return tx();
}

// Admin-entered sale (walk-in or manually logged) — completed immediately, cash/card in hand.
function createSale({ items, customer_name, channel, payment_method }) {
  return _recordSale({ items, customer_name, channel: channel || 'in_person', payment_method, status: 'completed' });
}

// Storefront checkout — stock is reserved immediately, but payment is unverified until
// the manager confirms it (see markSaleCompleted / cancelSale in the admin Sales screen).
function createOnlineOrder({ items, customer_name, customer_phone, delivery_note, payment_method }) {
  const crypto = require('crypto');
  const publicToken = crypto.randomBytes(16).toString('hex');
  const saleId = _recordSale({
    items, customer_name, customer_phone, delivery_note,
    channel: 'online', payment_method, status: 'pending', publicToken
  });
  return { saleId, publicToken };
}

function listSales({ from = null, to = null, limit = 100, status = null } = {}) {
  let sql = 'SELECT * FROM sales WHERE 1=1';
  const params = [];
  if (from) { sql += ' AND sale_date >= ?'; params.push(from); }
  if (to) { sql += ' AND sale_date <= ?'; params.push(to); }
  if (status) { sql += ' AND status = ?'; params.push(status); }
  sql += ' ORDER BY sale_date DESC LIMIT ?';
  params.push(limit);
  return db.prepare(sql).all(...params);
}

function pendingOnlineOrders() {
  return db.prepare(`SELECT * FROM sales WHERE channel = 'online' AND status = 'pending' ORDER BY sale_date ASC`).all();
}

function getSale(id) {
  const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(id);
  if (!sale) return null;
  sale.items = db.prepare(`
    SELECT si.*, v.size, v.color, v.sku, p.name AS product_name
    FROM sale_items si
    JOIN variants v ON v.id = si.variant_id
    JOIN products p ON p.id = v.product_id
    WHERE si.sale_id = ?
  `).all(id);
  return sale;
}

function getSaleByToken(token) {
  const sale = db.prepare('SELECT * FROM sales WHERE public_token = ?').get(token);
  if (!sale) return null;
  sale.items = db.prepare(`
    SELECT si.*, v.size, v.color, v.sku, p.name AS product_name
    FROM sale_items si
    JOIN variants v ON v.id = si.variant_id
    JOIN products p ON p.id = v.product_id
    WHERE si.sale_id = ?
  `).all(sale.id);
  return sale;
}

// Customer submits their mobile money transaction ID after paying. Order stays 'pending'
// until the manager cross-checks it against their MoMo/Airtel SMS and confirms below.
function submitPaymentReference(saleId, reference) {
  db.prepare(`UPDATE sales SET payment_reference = ? WHERE id = ? AND status = 'pending'`).run(reference, saleId);
}

function markSaleCompleted(saleId) {
  db.prepare(`UPDATE sales SET status = 'completed' WHERE id = ? AND status = 'pending'`).run(saleId);
}

// Cancels a pending order and puts the reserved stock back.
function cancelSale(saleId, note = 'Order cancelled') {
  const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(saleId);
  if (!sale || sale.status !== 'pending') return;
  const tx = db.transaction(() => {
    const items = db.prepare('SELECT * FROM sale_items WHERE sale_id = ?').all(saleId);
    for (const item of items) {
      db.prepare('UPDATE variants SET stock_qty = stock_qty + ? WHERE id = ?').run(item.quantity, item.variant_id);
      db.prepare('INSERT INTO stock_movements (variant_id, change_qty, reason, note) VALUES (?, ?, ?, ?)')
        .run(item.variant_id, item.quantity, 'adjustment', `${note} (Sale #${saleId})`);
    }
    db.prepare(`UPDATE sales SET status = 'cancelled' WHERE id = ?`).run(saleId);
  });
  tx();
}



// ---------- Reports ----------
function revenueSeries(groupBy = 'day', from = null, to = null) {
  const fmt = groupBy === 'month' ? '%Y-%m' : groupBy === 'week' ? '%Y-%W' : '%Y-%m-%d';
  let sql = `
    SELECT strftime('${fmt}', sale_date) AS period,
           SUM(total_amount) AS revenue,
           SUM(discount_amount) AS discounts,
           COUNT(*) AS orders
    FROM sales WHERE status = 'completed'
  `;
  const params = [];
  if (from) { sql += ' AND sale_date >= ?'; params.push(from); }
  if (to) { sql += ' AND sale_date <= ?'; params.push(to); }
  sql += ' GROUP BY period ORDER BY period ASC';
  return db.prepare(sql).all(...params);
}

function topSellers(limit = 10, from = null, to = null) {
  let sql = `
    SELECT p.name AS product_name, v.size, v.color,
           SUM(si.quantity) AS units_sold,
           SUM(si.quantity * si.unit_price) AS revenue
    FROM sale_items si
    JOIN variants v ON v.id = si.variant_id
    JOIN products p ON p.id = v.product_id
    JOIN sales s ON s.id = si.sale_id
    WHERE s.status = 'completed'
  `;
  const params = [];
  if (from) { sql += ' AND s.sale_date >= ?'; params.push(from); }
  if (to) { sql += ' AND s.sale_date <= ?'; params.push(to); }
  sql += ' GROUP BY v.id ORDER BY units_sold DESC LIMIT ?';
  params.push(limit);
  return db.prepare(sql).all(...params);
}

function profitSummary(from = null, to = null) {
  let sql = `
    SELECT SUM(si.quantity * si.unit_price) AS revenue,
           SUM(si.quantity * si.cost_price) AS cost,
           SUM(si.discount_amount) AS discounts,
           COUNT(DISTINCT s.id) AS orders
    FROM sale_items si
    JOIN sales s ON s.id = si.sale_id
    WHERE s.status = 'completed'
  `;
  const params = [];
  if (from) { sql += ' AND s.sale_date >= ?'; params.push(from); }
  if (to) { sql += ' AND s.sale_date <= ?'; params.push(to); }
  const row = db.prepare(sql).get(...params);
  const revenue = row.revenue || 0;
  const cost = row.cost || 0;
  return {
    revenue,
    cost,
    profit: revenue - cost,
    margin: revenue ? ((revenue - cost) / revenue) * 100 : 0,
    discounts: row.discounts || 0,
    orders: row.orders || 0
  };
}

function stockValue() {
  const row = db.prepare(`
    SELECT SUM(stock_qty * price) AS retail_value, SUM(stock_qty * cost_price) AS cost_value, SUM(stock_qty) AS total_units
    FROM variants WHERE is_active = 1
  `).get();
  return {
    retailValue: row.retail_value || 0,
    costValue: row.cost_value || 0,
    totalUnits: row.total_units || 0
  };
}

function discountImpact(from = null, to = null) {
  let sql = `
    SELECT d.name, COUNT(DISTINCT si.sale_id) AS orders_used, SUM(si.discount_amount) AS total_discount
    FROM sale_items si
    JOIN sales s ON s.id = si.sale_id
    JOIN discounts d ON d.id = si.discount_id
    WHERE s.status = 'completed' AND si.discount_amount > 0
  `;
  const params = [];
  if (from) { sql += ' AND s.sale_date >= ?'; params.push(from); }
  if (to) { sql += ' AND s.sale_date <= ?'; params.push(to); }
  sql += ' GROUP BY d.id ORDER BY total_discount DESC';
  return db.prepare(sql).all(...params);
}

// ---------- Jumia deal monitor ----------
// Insert if new (by source_url), or refresh price/stock if we've seen it before.
// Returns { id, isNew } so the caller knows whether to include it in a notification.
function upsertDeal(deal) {
  const existing = db.prepare('SELECT id, status FROM jumia_deals WHERE source_url = ?').get(deal.source_url);
  if (existing) {
    db.prepare(`
      UPDATE jumia_deals SET price = ?, original_price = ?, discount_percent = ?, stock_text = ?, found_at = datetime('now')
      WHERE id = ?
    `).run(deal.price, deal.original_price, deal.discount_percent, deal.stock_text, existing.id);
    return { id: existing.id, isNew: false };
  }
  const info = db.prepare(`
    INSERT INTO jumia_deals (source_url, title, category, price, original_price, discount_percent, stock_text, rating)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(deal.source_url, deal.title, deal.category, deal.price, deal.original_price, deal.discount_percent, deal.stock_text, deal.rating || null);
  return { id: info.lastInsertRowid, isNew: true };
}

function listNewDeals() {
  return db.prepare(`SELECT * FROM jumia_deals WHERE status IN ('new','notified') ORDER BY discount_percent DESC, found_at DESC`).all();
}

function markDealsNotified(ids) {
  if (!ids.length) return;
  const placeholders = ids.map(() => '?').join(',');
  db.prepare(`UPDATE jumia_deals SET status = 'notified' WHERE id IN (${placeholders}) AND status = 'new'`).run(...ids);
}

function dismissDeal(id) {
  db.prepare(`UPDATE jumia_deals SET status = 'dismissed' WHERE id = ?`).run(id);
}

// Creates a hidden draft product from a deal — price/stock are starting references
// only; the manager still has to add their own photo and confirm before publishing.
function createProductFromDeal(dealId) {
  const deal = db.prepare('SELECT * FROM jumia_deals WHERE id = ?').get(dealId);
  if (!deal) throw new Error('Deal not found');

  const tx = db.transaction(() => {
    const productId = db.prepare(`
      INSERT INTO products (name, description, is_active) VALUES (?, ?, 0)
    `).run(deal.title, `${deal.category || 'Item'} — reference price UGX ${Math.round(deal.price).toLocaleString()}. Add your own description and photo before publishing.`).lastInsertRowid;

    db.prepare(`
      INSERT INTO variants (product_id, price, cost_price, stock_qty, low_stock_threshold)
      VALUES (?, ?, 0, 0, 1)
    `).run(productId, deal.price);

    db.prepare(`UPDATE jumia_deals SET status = 'drafted', product_id = ? WHERE id = ?`).run(productId, dealId);
    return productId;
  });

  return tx();
}

// Manual equivalent — same hidden-draft pattern, fed by typed input (Admin → Quick
// add) instead of a scraped jumia_deals row.
function createDraftProduct({ title, note, category_id, price, stock_qty }) {
  const tx = db.transaction(() => {
    const description = note
      ? `${note}\n\nAdd your own description and photo before publishing.`
      : 'Add your own description and photo before publishing.';

    const productId = db.prepare(`
      INSERT INTO products (name, description, category_id, is_active) VALUES (?, ?, ?, 0)
    `).run(title, description, category_id || null).lastInsertRowid;

    db.prepare(`
      INSERT INTO variants (product_id, price, cost_price, stock_qty, low_stock_threshold)
      VALUES (?, ?, 0, ?, 1)
    `).run(productId, price, stock_qty || 0);

    return productId;
  });

  return tx();
}

module.exports = {
  listCategories, createCategory,
  listProducts, getProduct, createProduct, updateProduct, deleteProduct,
  addImage, deleteImage, setPrimaryImage,
  addVariant, updateVariant, deleteVariant, getVariant, getVariantWithProduct, adjustStock, lowStockVariants,
  listDiscounts, createDiscount, toggleDiscount, deleteDiscount, getEffectiveDiscount,
  createSale, createOnlineOrder, listSales, pendingOnlineOrders, getSale, getSaleByToken,
  submitPaymentReference, markSaleCompleted, cancelSale,
  revenueSeries, topSellers, profitSummary, stockValue, discountImpact,
  upsertDeal, listNewDeals, markDealsNotified, dismissDeal, createProductFromDeal, createDraftProduct
};
