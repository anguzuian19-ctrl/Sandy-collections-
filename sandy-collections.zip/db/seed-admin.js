// Creates or resets the admin account.
// Usage: node db/seed-admin.js <username> <password>
require('dotenv').config();
const bcrypt = require('bcrypt');
const db = require('./db');

const username = process.argv[2];
const password = process.argv[3];

if (!username || !password) {
  console.error('Usage: node db/seed-admin.js <username> <password>');
  process.exit(1);
}

if (password.length < 8) {
  console.error('Password must be at least 8 characters.');
  process.exit(1);
}

const hash = bcrypt.hashSync(password, 12);

const existing = db.prepare('SELECT id FROM admin_users WHERE username = ?').get(username);
if (existing) {
  db.prepare('UPDATE admin_users SET password_hash = ? WHERE username = ?').run(hash, username);
  console.log(`Password updated for admin user "${username}".`);
} else {
  db.prepare('INSERT INTO admin_users (username, password_hash) VALUES (?, ?)').run(username, hash);
  console.log(`Admin user "${username}" created.`);
}
