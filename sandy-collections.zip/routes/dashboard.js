const express = require('express');
const dayjs = require('dayjs');
const q = require('../db/queries');

const router = express.Router();

router.get('/', (req, res) => {
  const today = dayjs().format('YYYY-MM-DD');
  const monthStart = dayjs().startOf('month').format('YYYY-MM-DD');

  const todaySales = q.listSales({ from: today, status: 'completed' });
  const monthProfit = q.profitSummary(monthStart);
  const lowStock = q.lowStockVariants();
  const stock = q.stockValue();
  const recentSales = q.listSales({ limit: 8 });
  const pendingOrders = q.pendingOnlineOrders();

  const todayRevenue = todaySales.reduce((sum, s) => sum + s.total_amount, 0);

  res.render('admin/dashboard', {
    todayRevenue,
    todayOrders: todaySales.length,
    monthProfit,
    lowStock,
    stock,
    recentSales,
    pendingOrders
  });
});

module.exports = router;
