const express = require('express');
const q = require('../db/queries');

const router = express.Router();

router.get('/', (req, res) => {
  res.render('admin/deals', { categories: q.listCategories(), error: null });
});

router.post('/', (req, res) => {
  const { title, note, category_id, new_category, price, stock_qty } = req.body;

  if (!title || !price) {
    return res.status(400).render('admin/deals', {
      categories: q.listCategories(),
      error: 'Title and price are required.'
    });
  }

  let categoryId = category_id || null;
  if (new_category && new_category.trim()) {
    q.createCategory(new_category.trim());
    const cat = q.listCategories().find(c => c.name === new_category.trim());
    categoryId = cat ? cat.id : categoryId;
  }

  const productId = q.createDraftProduct({
    title,
    note,
    category_id: categoryId,
    price: parseFloat(price) || 0,
    stock_qty: parseInt(stock_qty, 10) || 0
  });

  res.redirect(`/admin/products/${productId}/edit`);
});

module.exports = router;
