const express = require('express');
const q = require('../db/queries');

const router = express.Router();

router.get('/', (req, res) => {
  const deals = q.listNewDeals();
  res.render('admin/deals', { deals });
});

router.post('/:id/draft', (req, res) => {
  const productId = q.createProductFromDeal(req.params.id);
  res.redirect(`/admin/products/${productId}/edit`);
});

router.post('/:id/dismiss', (req, res) => {
  q.dismissDeal(req.params.id);
  res.redirect('/admin/deals');
});

module.exports = router;
