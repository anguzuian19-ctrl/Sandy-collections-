const express = require('express');
const q = require('../db/queries');

const router = express.Router();

router.get('/', (req, res) => {
  const discounts = q.listDiscounts();
  const products = q.listProducts();
  const categories = q.listCategories();
  res.render('admin/discounts', { discounts, products, categories });
});

router.post('/new', (req, res) => {
  const { name, type, value, scope, scope_id, start_date, end_date } = req.body;
  q.createDiscount({
    name, type, value: parseFloat(value) || 0, scope,
    scope_id: scope_id || null, start_date: start_date || null, end_date: end_date || null
  });
  res.redirect('/admin/discounts');
});

router.post('/:id/toggle', (req, res) => {
  q.toggleDiscount(req.params.id, req.body.active === '1');
  res.redirect('/admin/discounts');
});

router.post('/:id/delete', (req, res) => {
  q.deleteDiscount(req.params.id);
  res.redirect('/admin/discounts');
});

module.exports = router;
