const express = require('express');
const fs = require('fs');
const path = require('path');
const q = require('../db/queries');
const upload = require('../middleware/upload');

const router = express.Router();

router.get('/', (req, res) => {
  const { search = '', category = '' } = req.query;
  const products = q.listProducts({ search, categoryId: category || null });
  const categories = q.listCategories();
  res.render('admin/products', { products, categories, search, selectedCategory: category });
});

router.get('/new', (req, res) => {
  res.render('admin/product-form', { product: null, categories: q.listCategories() });
});

router.post('/new', (req, res) => {
  const { name, description, category_id, new_category } = req.body;
  let categoryId = category_id || null;
  if (new_category && new_category.trim()) {
    q.createCategory(new_category.trim());
    const cat = q.listCategories().find(c => c.name === new_category.trim());
    categoryId = cat ? cat.id : categoryId;
  }
  const id = q.createProduct({ name, description, category_id: categoryId });
  res.redirect(`/admin/products/${id}`);
});

router.get('/:id', (req, res) => {
  const product = q.getProduct(req.params.id);
  if (!product) return res.status(404).send('Product not found');
  const discounts = q.listDiscounts().filter(d => d.is_active);
  res.render('admin/product-detail', { product, discounts });
});

router.get('/:id/edit', (req, res) => {
  const product = q.getProduct(req.params.id);
  if (!product) return res.status(404).send('Product not found');
  res.render('admin/product-form', { product, categories: q.listCategories() });
});

router.post('/:id/edit', (req, res) => {
  const { name, description, category_id, is_active } = req.body;
  q.updateProduct(req.params.id, { name, description, category_id: category_id || null, is_active: !!is_active });
  res.redirect(`/admin/products/${req.params.id}`);
});

router.post('/:id/delete', (req, res) => {
  const product = q.getProduct(req.params.id);
  if (product) {
    for (const img of product.images) {
      const p = path.join(__dirname, '..', 'uploads', img.filename);
      fs.existsSync(p) && fs.unlinkSync(p);
    }
  }
  q.deleteProduct(req.params.id);
  res.redirect('/admin/products');
});

// ---- Images ----
router.post('/:id/images', upload.array('images', 6), (req, res) => {
  const files = req.files || [];
  const existing = q.getProduct(req.params.id).images.length;
  files.forEach((f, i) => q.addImage(req.params.id, f.filename, existing === 0 && i === 0));
  res.redirect(`/admin/products/${req.params.id}`);
});

router.post('/:id/images/:imageId/primary', (req, res) => {
  q.setPrimaryImage(req.params.id, req.params.imageId);
  res.redirect(`/admin/products/${req.params.id}`);
});

router.post('/:id/images/:imageId/delete', (req, res) => {
  const img = q.deleteImage(req.params.imageId);
  if (img) {
    const p = path.join(__dirname, '..', 'uploads', img.filename);
    fs.existsSync(p) && fs.unlinkSync(p);
  }
  res.redirect(`/admin/products/${req.params.id}`);
});

// ---- Variants ----
router.post('/:id/variants', (req, res) => {
  const { size, color, sku, price, cost_price, stock_qty, low_stock_threshold } = req.body;
  q.addVariant(req.params.id, {
    size, color, sku,
    price: parseFloat(price) || 0,
    cost_price: parseFloat(cost_price) || 0,
    stock_qty: parseInt(stock_qty, 10) || 0,
    low_stock_threshold: parseInt(low_stock_threshold, 10) || 3
  });
  res.redirect(`/admin/products/${req.params.id}`);
});

router.post('/:id/variants/:variantId/edit', (req, res) => {
  const { size, color, sku, price, cost_price, low_stock_threshold, is_active } = req.body;
  q.updateVariant(req.params.variantId, {
    size, color, sku,
    price: parseFloat(price) || 0,
    cost_price: parseFloat(cost_price) || 0,
    low_stock_threshold: parseInt(low_stock_threshold, 10) || 3,
    is_active: !!is_active
  });
  res.redirect(`/admin/products/${req.params.id}`);
});

router.post('/:id/variants/:variantId/delete', (req, res) => {
  q.deleteVariant(req.params.variantId);
  res.redirect(`/admin/products/${req.params.id}`);
});

router.post('/:id/variants/:variantId/stock', (req, res) => {
  const { change_qty, reason, note } = req.body;
  const change = parseInt(change_qty, 10);
  if (change) {
    q.adjustStock(req.params.variantId, change, reason || 'adjustment', note || null);
  }
  res.redirect(`/admin/products/${req.params.id}`);
});

module.exports = router;
