const express = require('express');
const dayjs = require('dayjs');
const q = require('../db/queries');

const router = express.Router();

router.get('/', (req, res) => {
  const period = req.query.period || 'month'; // week | month | year
  let from;
  if (period === 'week') from = dayjs().subtract(7, 'day').format('YYYY-MM-DD');
  else if (period === 'year') from = dayjs().subtract(365, 'day').format('YYYY-MM-DD');
  else from = dayjs().subtract(30, 'day').format('YYYY-MM-DD');

  const groupBy = period === 'year' ? 'month' : 'day';

  const revenue = q.revenueSeries(groupBy, from);
  const profit = q.profitSummary(from);
  const top = q.topSellers(10, from);
  const lowStock = q.lowStockVariants();
  const stock = q.stockValue();
  const discountImpact = q.discountImpact(from);

  res.render('admin/reports', { period, revenue, profit, top, lowStock, stock, discountImpact });
});

module.exports = router;
