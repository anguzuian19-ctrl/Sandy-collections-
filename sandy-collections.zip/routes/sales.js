const express = require('express');
const db = require('../db/db');
const q = require('../db/queries');

const router = express.Router();

router.get('/', (req, res) => {
  const status = req.query.status || null;
  const sales = q.listSales({ limit: 200, status });
  res.render('admin/sales', { sales, error: null, statusFilter: status });
});

router.get('/new', (req, res) => {
  const products = q.listProducts({ activeOnly: true });
  res.render('admin/sale-new', { products, error: null });
});

router.post('/new', (req, res) => {
  try {
    // form sends parallel arrays: variant_id[], quantity[]
    let variantIds = req.body.variant_id;
    let quantities = req.body.quantity;
    if (!Array.isArray(variantIds)) variantIds = variantIds ? [variantIds] : [];
    if (!Array.isArray(quantities)) quantities = quantities ? [quantities] : [];

    const items = variantIds
      .map((id, i) => ({ variant_id: parseInt(id, 10), quantity: parseInt(quantities[i], 10) }))
      .filter(it => it.variant_id && it.quantity > 0);

    if (!items.length) throw new Error('Add at least one item with a quantity.');

    const saleId = q.createSale({
      items,
      customer_name: req.body.customer_name || null,
      channel: req.body.channel || 'in_person',
      payment_method: req.body.payment_method || null
    });
    res.redirect(`/admin/sales/${saleId}`);
  } catch (err) {
    const products = q.listProducts({ activeOnly: true });
    res.status(400).render('admin/sale-new', { products, error: err.message });
  }
});

router.get('/:id', (req, res) => {
  const sale = q.getSale(req.params.id);
  if (!sale) return res.status(404).send('Sale not found');
  res.render('admin/sale-detail', { sale });
});

router.post('/:id/confirm', (req, res) => {
  q.markSaleCompleted(req.params.id);
  res.redirect(`/admin/sales/${req.params.id}`);
});

router.post('/:id/cancel', (req, res) => {
  q.cancelSale(req.params.id, 'Cancelled by manager');
  res.redirect(`/admin/sales/${req.params.id}`);
});

// Small JSON endpoint used by the "new sale" form to fetch variants for a chosen product
router.get('/api/variants/:productId', (req, res) => {
  const variants = db.prepare(`
    SELECT id, size, color, sku, price, stock_qty FROM variants
    WHERE product_id = ? AND is_active = 1 ORDER BY size, color
  `).all(req.params.productId);
  res.json(variants);
});

module.exports = router;
