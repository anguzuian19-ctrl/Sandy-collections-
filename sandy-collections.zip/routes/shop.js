const express = require('express');
const q = require('../db/queries');
const payments = require('../services/payments');
const telegram = require('../services/telegram');

const router = express.Router();

function getCart(req) {
  if (!req.session.cart) req.session.cart = [];
  return req.session.cart;
}

// Resolves the session cart into full line items with live price/discount/stock,
// used by both the cart page and checkout so they always agree with each other.
function resolveCart(req) {
  const cart = getCart(req);
  const lines = [];
  let subtotal = 0;
  let discountTotal = 0;

  for (const entry of cart) {
    const variant = q.getVariantWithProduct(entry.variant_id);
    if (!variant || !variant.is_active) continue;
    const eff = q.getEffectiveDiscount(variant);
    const unitPrice = eff ? eff.finalPrice : variant.price;
    const quantity = Math.min(entry.quantity, variant.stock_qty);
    const lineTotal = unitPrice * quantity;
    lines.push({
      variant, quantity, unitPrice, originalPrice: variant.price,
      hasDiscount: !!eff, lineTotal, maxAvailable: variant.stock_qty,
      quantityCapped: quantity < entry.quantity
    });
    subtotal += lineTotal;
    if (eff) discountTotal += eff.amount * quantity;
  }

  return { lines, subtotal, discountTotal, isEmpty: lines.length === 0 };
}

// ---------- Catalog ----------
router.get('/', (req, res) => {
  const { search = '', category = '' } = req.query;
  const products = q.listProducts({ search, categoryId: category || null, activeOnly: true });
  const categories = q.listCategories();
  res.render('shop/home', { products, categories, search, selectedCategory: category });
});

router.get('/product/:id', (req, res) => {
  const product = q.getProduct(req.params.id);
  if (!product || !product.is_active) return res.status(404).render('shop/not-found');

  const variants = product.variants
    .filter(v => v.is_active)
    .map(v => {
      const eff = q.getEffectiveDiscount(v);
      return { ...v, finalPrice: eff ? eff.finalPrice : v.price, hasDiscount: !!eff };
    });

  res.render('shop/product', { product, variants });
});

// ---------- Cart ----------
router.post('/cart/add', (req, res) => {
  const variantId = parseInt(req.body.variant_id, 10);
  const quantity = Math.max(1, parseInt(req.body.quantity, 10) || 1);
  const variant = q.getVariantWithProduct(variantId);
  if (!variant) return res.redirect(req.get('Referer') || '/');

  const cart = getCart(req);
  const existing = cart.find(c => c.variant_id === variantId);
  if (existing) existing.quantity = Math.min(existing.quantity + quantity, variant.stock_qty);
  else cart.push({ variant_id: variantId, quantity: Math.min(quantity, variant.stock_qty) });

  res.redirect('/cart');
});

router.post('/cart/update', (req, res) => {
  const variantId = parseInt(req.body.variant_id, 10);
  const quantity = parseInt(req.body.quantity, 10);
  const cart = getCart(req);
  const existing = cart.find(c => c.variant_id === variantId);
  if (existing) {
    if (quantity <= 0) {
      req.session.cart = cart.filter(c => c.variant_id !== variantId);
    } else {
      const variant = q.getVariantWithProduct(variantId);
      existing.quantity = variant ? Math.min(quantity, variant.stock_qty) : quantity;
    }
  }
  res.redirect('/cart');
});

router.post('/cart/remove', (req, res) => {
  const variantId = parseInt(req.body.variant_id, 10);
  req.session.cart = getCart(req).filter(c => c.variant_id !== variantId);
  res.redirect('/cart');
});

router.get('/cart', (req, res) => {
  const cart = resolveCart(req);
  res.render('shop/cart', { cart });
});

// ---------- Checkout ----------
router.get('/checkout', (req, res) => {
  const cart = resolveCart(req);
  if (cart.isEmpty) return res.redirect('/cart');
  res.render('shop/checkout', { cart, error: null });
});

router.post('/checkout', (req, res) => {
  const cart = resolveCart(req);
  if (cart.isEmpty) return res.redirect('/cart');

  const { customer_name, customer_phone, delivery_note, payment_method } = req.body;
  if (!customer_name || !customer_phone) {
    return res.status(400).render('shop/checkout', { cart, error: 'Name and phone number are required.' });
  }

  try {
    const items = cart.lines.map(l => ({ variant_id: l.variant.id, quantity: l.quantity }));
    const { saleId, publicToken } = q.createOnlineOrder({
      items, customer_name, customer_phone, delivery_note,
      payment_method: payment_method || 'mtn_momo'
    });
    req.session.cart = [];
    const sale = q.getSale(saleId);
    telegram.notifyNewOrder(sale).catch(() => {}); // best-effort, never block checkout on this
    res.redirect(`/order/${publicToken}`);
  } catch (err) {
    res.status(400).render('shop/checkout', { cart, error: err.message });
  }
});

// ---------- Order status / payment ----------
router.get('/order/:token', (req, res) => {
  const order = q.getSaleByToken(req.params.token);
  if (!order) return res.status(404).render('shop/not-found');

  let instructions = null;
  if (order.status === 'pending' && order.payment_method !== 'cod') {
    const provider = payments.getProvider();
    instructions = provider.getInstructions({ amount: order.total_amount, method: order.payment_method });
  }
  res.render('shop/order', { order, instructions });
});

router.post('/order/:token/reference', (req, res) => {
  const order = q.getSaleByToken(req.params.token);
  if (!order || order.status !== 'pending') return res.redirect(`/order/${req.params.token}`);
  const reference = (req.body.reference || '').trim();
  if (reference) q.submitPaymentReference(order.id, reference);
  res.redirect(`/order/${req.params.token}`);
});

module.exports = router;
