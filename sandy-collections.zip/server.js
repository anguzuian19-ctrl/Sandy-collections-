require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const path = require('path');

require('./db/db'); // ensures schema is applied before routes load

const { requireAuth } = require('./middleware/auth');
const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const productRoutes = require('./routes/products');
const discountRoutes = require('./routes/discounts');
const saleRoutes = require('./routes/sales');
const reportRoutes = require('./routes/reports');
const dealRoutes = require('./routes/deals');
const shopRoutes = require('./routes/shop');

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.SESSION_SECRET) {
  console.error('Missing SESSION_SECRET in .env — refusing to start. Copy .env.example to .env and set one.');
  process.exit(1);
}

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('trust proxy', 1); // running behind Nginx on the VPS

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/public', express.static(path.join(__dirname, 'public')));

app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: path.join(__dirname, 'db') }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 12, // 12 hours
    httpOnly: true,
    secure: process.env.COOKIE_SECURE === 'true',
    sameSite: 'lax'
  }
}));

// Make the logged-in username and cart count available to every view
app.use((req, res, next) => {
  res.locals.currentUser = req.session ? req.session.username : null;
  res.locals.brandName = 'Real Collections';
  res.locals.cartCount = req.session && req.session.cart
    ? req.session.cart.reduce((n, c) => n + c.quantity, 0)
    : 0;
  next();
});

app.use('/admin', authRoutes);
app.use('/admin', requireAuth, dashboardRoutes);
app.use('/admin/products', requireAuth, productRoutes);
app.use('/admin/discounts', requireAuth, discountRoutes);
app.use('/admin/sales', requireAuth, saleRoutes);
app.use('/admin/reports', requireAuth, reportRoutes);
app.use('/admin/deals', requireAuth, dealRoutes);
app.use('/', shopRoutes);

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send(`Something went wrong: ${err.message}`);
});

app.use((req, res) => res.status(404).send('Page not found'));

app.listen(PORT, () => {
  console.log(`Real Collections admin running on http://localhost:${PORT}`);
});
