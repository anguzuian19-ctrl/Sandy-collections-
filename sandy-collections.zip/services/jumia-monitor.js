// Jumia deal monitor — CURRENTLY NON-FUNCTIONAL.
//
// Jumia's WAF returns 403 on every request from this server regardless of headers
// used (tested with a full browser-realistic header set — see git history). Most
// likely cause: the Lightsail/AWS IP range itself is flagged as datacenter traffic,
// which header tuning can't fix. The next real fix would be a headless browser
// (Puppeteer/Playwright) presenting a genuine browser fingerprint, but that needs
// 300-500MB+ RAM just to launch Chromium — not viable on this box's 512MB.
//
// Left in place in case this ever moves to bigger infrastructure. Until then, use
// Admin → Quick add (routes/deals.js) for manual entry instead — same fast hidden-
// draft workflow, just fed by typing instead of scraping.
//
// Original usage, if revived: node services/jumia-monitor.js --dry-run

require('dotenv').config();
const cheerio = require('cheerio');
const q = require('../db/queries');
const telegram = require('./telegram');

const DEFAULT_CATEGORIES = [
  'https://www.jumia.ug/electronics/flash-sales/',
  'https://www.jumia.ug/home-office/flash-sales/',
  'https://www.jumia.ug/phones-tablets/flash-sales/',
  'https://www.jumia.ug/computing/flash-sales/'
];

const MIN_DISCOUNT = parseInt(process.env.JUMIA_MIN_DISCOUNT, 10) || 30;
const CATEGORIES = process.env.JUMIA_CATEGORIES
  ? process.env.JUMIA_CATEGORIES.split(',').map(s => s.trim()).filter(Boolean)
  : DEFAULT_CATEGORIES;

const UGX = /UGX\s?([\d,]+)/g;
const DISCOUNT = /(\d{1,3})%/;
const STOCK = /(\d+)\s*items? left/i;

function categoryFromUrl(url) {
  const m = url.match(/jumia\.ug\/([a-z-]+)\/flash-sales/);
  return m ? m[1] : 'other';
}

async function fetchCategory(url) {
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'Referer': 'https://www.jumia.ug/',
      'Upgrade-Insecure-Requests': '1',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Fetch-User': '?1'
    }
  });
  if (!res.ok) throw new Error(`${url} -> HTTP ${res.status}`);
  return res.text();
}

// Product links look like https://www.jumia.ug/some-title-259855757.html
function isProductLink(href) {
  return typeof href === 'string' && /-\d{5,}\.html$/.test(href) && !href.includes('/customer/');
}

function parseCategory(html, categoryUrl) {
  const $ = cheerio.load(html);
  const category = categoryFromUrl(categoryUrl);
  const found = [];
  const seenUrls = new Set();

  $('a[href]').each((_, el) => {
    const href = $(el).attr('href');
    if (!isProductLink(href) || seenUrls.has(href)) return;

    // Walk up a few ancestors to find a block that actually contains price text —
    // product cards nest the link and the price/stock info as siblings, not always
    // inside the <a> itself.
    let $card = $(el);
    let text = $card.text();
    let hops = 0;
    while (!/UGX/.test(text) && hops < 4) {
      $card = $card.parent();
      text = $card.text();
      hops++;
    }
    if (!/UGX/.test(text)) return;

    const prices = [...text.matchAll(UGX)].map(m => parseFloat(m[1].replace(/,/g, '')));
    if (prices.length < 2) return; // need both current + original price to know it's a real deal

    const discountMatch = text.match(DISCOUNT);
    const discount = discountMatch ? parseInt(discountMatch[1], 10) : null;
    if (!discount || discount < MIN_DISCOUNT) return;

    const stockMatch = text.match(STOCK);
    const title = ($(el).attr('title') || $(el).text() || '').trim().split('\n')[0].slice(0, 180);
    if (!title) return;

    seenUrls.add(href);
    found.push({
      source_url: href.startsWith('http') ? href : `https://www.jumia.ug${href}`,
      title,
      category,
      price: Math.min(...prices),
      original_price: Math.max(...prices),
      discount_percent: discount,
      stock_text: stockMatch ? `${stockMatch[1]} items left` : null
    });
  });

  return found;
}

async function run({ dryRun = false } = {}) {
  const allDeals = [];
  for (const url of CATEGORIES) {
    try {
      const html = await fetchCategory(url);
      const deals = parseCategory(html, url);
      console.log(`${url} -> ${deals.length} deals >= ${MIN_DISCOUNT}% off`);
      allDeals.push(...deals);
    } catch (err) {
      console.error(`Failed on ${url}:`, err.message);
    }
  }

  if (dryRun) {
    console.log(JSON.stringify(allDeals, null, 2));
    console.log(`\nDry run: ${allDeals.length} deals found across ${CATEGORIES.length} categories. Nothing written to DB, no Telegram sent.`);
    return;
  }

  const newlyFound = [];
  for (const deal of allDeals) {
    const { id, isNew } = q.upsertDeal(deal);
    if (isNew) newlyFound.push({ ...deal, id });
  }

  console.log(`${newlyFound.length} new deals (${allDeals.length} total seen this run).`);

  if (newlyFound.length) {
    await telegram.notifyNewDeals(newlyFound);
    q.markDealsNotified(newlyFound.map(d => d.id));
  }
}

if (require.main === module) {
  const dryRun = process.argv.includes('--dry-run');
  run({ dryRun }).catch(err => {
    console.error('Jumia monitor failed:', err);
    process.exit(1);
  });
}

module.exports = { run, parseCategory };
