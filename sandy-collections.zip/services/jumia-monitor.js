// Jumia deal monitor.
//
// Fetches the flash-sales page for each configured category, pulls out price/
// stock/discount data, and records anything new above the discount threshold.
// Run manually to test: node services/jumia-monitor.js --dry-run
// Run for real (writes to DB + notifies Telegram): node services/jumia-monitor.js
// Intended to be triggered periodically via crontab — see README.
//
// NOTE ON SELECTORS: this parses by URL shape and text patterns (UGX amounts,
// "N items left", discount %) rather than CSS class names. Jumia's markup wasn't
// directly inspectable while building this, so the very first real run should be
// a --dry-run to confirm the output looks right before trusting it unattended.

require('dotenv').config();
const cheerio = require('cheerio');
const q = require('../db/queries');
const telegram = require('./telegram');

const DEFAULT_CATEGORIES = [
  'https://www.jumia.ug/electronics/flash-sales/',
  'https://www.jumia.ug/home-office/flash-sales/',
  'https://www.jumia.ug/phones-tablets/flash-sales/',
  'https://www.jumia.ug/computing/flash-sales/'
];

const MIN_DISCOUNT = parseInt(process.env.JUMIA_MIN_DISCOUNT, 10) || 30;
const CATEGORIES = process.env.JUMIA_CATEGORIES
  ? process.env.JUMIA_CATEGORIES.split(',').map(s => s.trim()).filter(Boolean)
  : DEFAULT_CATEGORIES;

const UGX = /UGX\s?([\d,]+)/g;
const DISCOUNT = /(\d{1,3})%/;
const STOCK = /(\d+)\s*items? left/i;

function categoryFromUrl(url) {
  const m = url.match(/jumia\.ug\/([a-z-]+)\/flash-sales/);
  return m ? m[1] : 'other';
}

async function fetchCategory(url) {
  const res = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
  });
  if (!res.ok) throw new Error(`${url} -> HTTP ${res.status}`);
  return res.text();
}

// Product links look like https://www.jumia.ug/some-title-259855757.html
function isProductLink(href) {
  return typeof href === 'string' && /-\d{5,}\.html$/.test(href) && !href.includes('/customer/');
}

function parseCategory(html, categoryUrl) {
  const $ = cheerio.load(html);
  const category = categoryFromUrl(categoryUrl);
  const found = [];
  const seenUrls = new Set();

  $('a[href]').each((_, el) => {
    const href = $(el).attr('href');
    if (!isProductLink(href) || seenUrls.has(href)) return;

    // Walk up a few ancestors to find a block that actually contains price text —
    // product cards nest the link and the price/stock info as siblings, not always
    // inside the <a> itself.
    let $card = $(el);
    let text = $card.text();
    let hops = 0;
    while (!/UGX/.test(text) && hops < 4) {
      $card = $card.parent();
      text = $card.text();
      hops++;
    }
    if (!/UGX/.test(text)) return;

    const prices = [...text.matchAll(UGX)].map(m => parseFloat(m[1].replace(/,/g, '')));
    if (prices.length < 2) return; // need both current + original price to know it's a real deal

    const discountMatch = text.match(DISCOUNT);
    const discount = discountMatch ? parseInt(discountMatch[1], 10) : null;
    if (!discount || discount < MIN_DISCOUNT) return;

    const stockMatch = text.match(STOCK);
    const title = ($(el).attr('title') || $(el).text() || '').trim().split('\n')[0].slice(0, 180);
    if (!title) return;

    seenUrls.add(href);
    found.push({
      source_url: href.startsWith('http') ? href : `https://www.jumia.ug${href}`,
      title,
      category,
      price: Math.min(...prices),
      original_price: Math.max(...prices),
      discount_percent: discount,
      stock_text: stockMatch ? `${stockMatch[1]} items left` : null
    });
  });

  return found;
}

async function run({ dryRun = false } = {}) {
  const allDeals = [];
  for (const url of CATEGORIES) {
    try {
      const html = await fetchCategory(url);
      const deals = parseCategory(html, url);
      console.log(`${url} -> ${deals.length} deals >= ${MIN_DISCOUNT}% off`);
      allDeals.push(...deals);
    } catch (err) {
      console.error(`Failed on ${url}:`, err.message);
    }
  }

  if (dryRun) {
    console.log(JSON.stringify(allDeals, null, 2));
    console.log(`\nDry run: ${allDeals.length} deals found across ${CATEGORIES.length} categories. Nothing written to DB, no Telegram sent.`);
    return;
  }

  const newlyFound = [];
  for (const deal of allDeals) {
    const { id, isNew } = q.upsertDeal(deal);
    if (isNew) newlyFound.push({ ...deal, id });
  }

  console.log(`${newlyFound.length} new deals (${allDeals.length} total seen this run).`);

  if (newlyFound.length) {
    await telegram.notifyNewDeals(newlyFound);
    q.markDealsNotified(newlyFound.map(d => d.id));
  }
}

if (require.main === module) {
  const dryRun = process.argv.includes('--dry-run');
  run({ dryRun }).catch(err => {
    console.error('Jumia monitor failed:', err);
    process.exit(1);
  });
}

module.exports = { run, parseCategory };
