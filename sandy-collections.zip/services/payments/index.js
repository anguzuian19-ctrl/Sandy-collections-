const manual = require('./manual');
const xyle = require('./xyle');

const providers = { manual, xyle };

function getProvider() {
  const key = process.env.PAYMENT_PROVIDER || 'manual';
  return providers[key] || manual;
}

module.exports = { getProvider };
