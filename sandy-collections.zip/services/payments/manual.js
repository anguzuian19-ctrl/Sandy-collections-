// "Manual" mobile money provider.
//
// There's no aggregator API behind this — the customer sends money directly to the
// business's own MTN MoMo / Airtel Money number and types the transaction reference
// (from the SMS they receive) back into the order page. The manager then confirms it
// against their own phone from the admin Sales screen (Pending orders).
//
// This is the standard stopgap Ugandan shops use before they have a payment aggregator
// account (Xyle, Flutterwave, Pesapal, etc.) — no fees, no integration, works same day.
// USSD codes are current as of mid-2026 but menus do change; double check them yourself
// on your own line before showing this to a client.
//
// Swap PAYMENT_PROVIDER=xyle in .env once Xyle access is live — see services/payments/xyle.js.

function getInstructions({ amount, method }) {
  const business = process.env.BUSINESS_NAME || 'Sandy Collections';

  if (method === 'airtel_money') {
    const number = process.env.AIRTEL_MONEY_NUMBER || '07XXXXXXXX';
    return {
      label: 'Airtel Money',
      number,
      recipientName: process.env.AIRTEL_MONEY_NAME || business,
      steps: [
        `Dial *185# on your Airtel line`,
        `Choose "Send Money" and enter ${number}`,
        `Enter the amount: UGX ${Math.round(amount).toLocaleString()}`,
        `Confirm with your Airtel Money PIN`,
        `You'll get an SMS with a transaction ID — enter it below`
      ]
    };
  }

  // default: MTN MoMo
  const number = process.env.MTN_MOMO_NUMBER || '07XXXXXXXX';
  return {
    label: 'MTN Mobile Money',
    number,
    recipientName: process.env.MTN_MOMO_NAME || business,
    steps: [
      `Dial *165*1# on your MTN line`,
      `Enter ${number} as the recipient`,
      `Enter the amount: UGX ${Math.round(amount).toLocaleString()}`,
      `Confirm with your MoMo PIN`,
      `You'll get an SMS with a transaction ID — enter it below`
    ]
  };
}

// No automatic verification available — just records what the customer typed for the
// manager to cross-check manually. Returns nothing to confirm; status stays "pending".
async function submitReference({ reference }) {
  return { reference, verified: false };
}

module.exports = { name: 'manual', getInstructions, submitReference };
