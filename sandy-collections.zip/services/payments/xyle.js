// Xyle payment provider — PLACEHOLDER.
//
// Not wired up yet: Xyle requires a commitment payment before issuing an API key.
// This file exists so switching providers later is a drop-in change (see index.js)
// instead of a rewrite of the checkout flow.
//
// When you have the API key and Xyle's docs in hand, implement:
//
//   getInstructions({ amount, method })
//     -> Most aggregators either (a) return a USSD push prompt straight to the
//        customer's phone (no manual entry needed), or (b) return a redirect/checkout
//        URL. Either way this function's job is to kick that off and return whatever
//        the order-confirmation page needs to show ("check your phone" / a redirect link).
//
//   submitReference({ saleId, reference })
//     -> Only needed if Xyle is reference-based rather than push+webhook. If Xyle
//        confirms payment via webhook instead, add a routes/webhooks.js that verifies
//        Xyle's signature and calls queries.markSaleCompleted(saleId) directly —
//        that path doesn't need this function at all.
//
// Until then, PAYMENT_PROVIDER stays "manual" in .env.

function getInstructions() {
  throw new Error('Xyle provider not yet implemented — set PAYMENT_PROVIDER=manual in .env');
}

async function submitReference() {
  throw new Error('Xyle provider not yet implemented — set PAYMENT_PROVIDER=manual in .env');
}

module.exports = { name: 'xyle', getInstructions, submitReference };
