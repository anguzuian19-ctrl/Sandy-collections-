// Minimal Telegram notifier. We only ever send messages (deal alerts, order
// notifications) — no need for a polling/webhook library, just a plain HTTPS call.

async function sendMessage(text) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.warn('Telegram not configured (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID missing) — skipping notification.');
    return null;
  }

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
        disable_web_page_preview: true
      })
    });
    const data = await res.json();
    if (!data.ok) console.error('Telegram send failed:', data.description);
    return data;
  } catch (err) {
    console.error('Telegram send error:', err.message);
    return null;
  }
}

function notifyNewOrder(sale) {
  const lines = [
    `<b>New order — #${sale.id}</b>`,
    `${sale.customer_name || 'Guest'} · ${sale.customer_phone || 'no phone'}`,
    `Payment: ${sale.payment_method === 'cod' ? 'Cash on Delivery' : sale.payment_method}`,
    `Total: UGX ${Math.round(sale.total_amount).toLocaleString()}`
  ];
  if (sale.delivery_note) lines.push(`Notes: ${sale.delivery_note}`);
  return sendMessage(lines.join('\n'));
}

function notifyNewDeals(deals) {
  if (!deals.length) return null;
  const lines = [`<b>${deals.length} new Jumia deal${deals.length === 1 ? '' : 's'} found</b>`, ''];
  for (const d of deals.slice(0, 10)) {
    lines.push(
      `${d.title}\nUGX ${Math.round(d.price).toLocaleString()} (was ${Math.round(d.original_price).toLocaleString()}, -${d.discount_percent}%) · ${d.stock_text || ''}\n${d.source_url}`
    );
    lines.push('');
  }
  if (deals.length > 10) lines.push(`...and ${deals.length - 10} more. Check /admin/deals.`);
  return sendMessage(lines.join('\n'));
}

module.exports = { sendMessage, notifyNewOrder, notifyNewDeals };
